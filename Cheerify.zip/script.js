/* .js files add interaction to your website */


// KEY FEATURE: Generate a fact
var factList = [
  "One in five American adults experienced a mental health issue.", 
  "3.8% of U.S. adults experienced a co-occurring substance use disorder and mental illness in 2019 (9.5 million people).", 
  "One in 25 Americans lived with a serious mental illness, such as schizophrenia, bipolar disorder, or major depression", 
  "The prevalence of AMI (any mental illness) was higher among females (24.5%) than males (16.3%).", 
  "In 2019, among the 51.5 million adults with AMI, 23.0 million (44.8%) received mental health services in the past year.", 
  "In 2019, there were an estimated 13.1 million adults aged 18 or older in the United States with SMI. This number represented 5.2% of all U.S. adults."
];

var fact = document.getElementById("fact");
var factBtn = document.getElementById("factBtn");
var count = 0;

if (factBtn) {
  factBtn.addEventListener("click", displayFact);
}

function displayFact() {
  fact.innerHTML = factList[count];
  count++;
  if (count == factList.length) {
    count = 0;
  }
}

var input = document.querySelectorAll('#enter input[type=text]')[0],
    entries = {},
    completed = {},
    reminders = {
      create: function(text) {
        if (text != '') {
          var entry = Date.now();
          if (localStorage.entries) {
            entries = JSON.parse(localStorage.entries);
          }
          entries[entry] = text;
          localStorage.entries = JSON.stringify(entries);
          input.value = '';
          reminders.display('entries');
        }
        input.focus();
      },
      display: function(list) {
        var list = JSON.parse(localStorage[list]);
        for (var entry in list) {
          var box = document.createElement('section'),
              task = document.createElement('input'),
              exit = document.createElement('input');
          task.type = 'text';
          task.setAttribute('onblur', 'reminders.edit(this.value, this.parentNode.id)');
          task.value = list[entry];
          exit.type = 'button';
          exit.setAttribute('onclick', 'reminders.complete(this.parentNode.id)');
          exit.value = '×';
          box.id = entry;
          box.appendChild(task);
          box.appendChild(exit);
          if (!document.getElementById(entry)) {
            document.getElementsByTagName('body')[0].insertBefore(box, document.getElementById('enter'));
          }
        }
      },
      edit: function (text, id) {
        entries = JSON.parse(localStorage.entries);
        entries[id] = text;
        localStorage.entries = JSON.stringify(entries);
      },
      complete: function (id) {
        entries = JSON.parse(localStorage.entries);
        if (localStorage.completed) {
          completed = JSON.parse(localStorage.completed);
        }
        completed[id] = entries[id];
        delete entries[id];
        localStorage.completed = JSON.stringify(completed);
        localStorage.entries = JSON.stringify(entries);
        reminders.display('entries');
        document.getElementById(id).remove();
      }
    }
document.onkeydown = function(e) {
  e = e || window.event;
  var charCode = (typeof e.which == "number") ? e.which : e.keyCode;
  if (charCode == 13) { reminders.create(input.value); } /* enter key creates new reminder */
}
reminders.display('entries');