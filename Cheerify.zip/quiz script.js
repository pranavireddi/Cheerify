var adventurerScore = 0;
var relaxerScore = 0;

var questionCount = 0;

var q1a1 = document.getElementById("q1a1");
var q1a2 = document.getElementById("q1a2");
var q1a3 = document.getElementById("q1a3");
var q1a4 = document.getElementById("q1a4");

var q2a1 = document.getElementById("q2a1");
var q2a2 = document.getElementById("q2a2");
var q2a3 = document.getElementById("q2a3");
var q2a4 = document.getElementById("q2a4");

var q3a1 = document.getElementById("q3a1");
var q3a2 = document.getElementById("q3a2");
var q3a3 = document.getElementById("q3a3");
var q3a4 = document.getElementById("q3a4");

var restart = document.getElementById("restart");

q1a1.addEventListener("click", relaxer);
q1a2.addEventListener("click", adventurer);
q1a3.addEventListener("click", relaxer);
q1a4.addEventListener("click", adventurer);

q2a1.addEventListener("click", relaxer);
q2a2.addEventListener("click", adventurer);
q2a3.addEventListener("click", relaxer);
q2a4.addEventListener("click", adventurer);

q3a1.addEventListener("click", relaxer);
q3a2.addEventListener("click", adventurer);
q3a3.addEventListener("click", adventurer);
q3a4.addEventListener("click", relaxer);

restart.addEventListener("click", restartNow)



function relaxer(){
  relaxerScore += 1;
  questionCount += 1;

  console.log("questionCount: " + questionCount + " Relaxer Score: " + relaxerScore);

  if (questionCount == 3) {
  console.log("The quiz is done!");

  updateResult();

  }

}

function adventurer(){
  adventurerScore += 1;
  questionCount += 1;

 console.log("questionCount: " + questionCount + " Adventurer Score: " + adventurerScore);

 if (questionCount == 3) {

  console.log("The quiz is done!");

  updateResult()
  
  }

  

}

function updateResult(){
  
  if (adventurerScore >= 2){
  result.innerHTML = "You are an adventurer!";
  console.log("You are an adventurer!");
  }
  if (relaxerScore >= 2){
  result.innerHTML = "You are a relaxer!";
  console.log("You are a relaxer!");
  }

}

function restartNow(){
  
  adventurerScore = 0;
  relaxerScore = 0;
  questionCount = 0;
  result.innerHTML = "Your result is...";
  console.log("Restarted");

}